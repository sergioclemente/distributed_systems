echo "state 1"
cat storage/1/facebookstate.txt

echo "state 2"
cat storage/2/facebookstate.txt

echo "state 3"
cat storage/3/facebookstate.txt

echo "state 4"
cat storage/4/facebookstate.txt

echo "state 5"
cat storage/5/facebookstate.txt

package node.twophasecommit;

public enum Decision {
	Commit,
	Abort,
	NotDecided
}

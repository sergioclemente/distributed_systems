package node.twophasecommit;

public enum Vote {
	Yes,
	No,
	None
}

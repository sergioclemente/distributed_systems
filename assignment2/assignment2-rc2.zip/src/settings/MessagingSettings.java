package settings;

public class MessagingSettings 
{
	public static final boolean SuppressInfoSpew = false;
	public static final boolean SuppressWarningSpew = false;
	public static final boolean SuppressErrorSpew = false;
	public static final Integer Timeout = 3;
	public static final Integer MaxTimeout = 3*Timeout;
	
}
